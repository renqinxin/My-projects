ENCRYPTION = 'no'
SERVER_PORT = 20100
is_allowed = True